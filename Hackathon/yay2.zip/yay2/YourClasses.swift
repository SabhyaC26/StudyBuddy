//
//  YourClasses.swift
//  yay2
//
//  Created by Lillian Joyce on 4/18/19.
//  Copyright © 2019 Lillian Joyce. All rights reserved.
//

import Foundation

import UIKit

class YourClasses{
    var classname: String
    //var otherstuff: String
    init(classname: String) {
        self.classname = classname
        //self.otherstuff = otherstuff
    }
}
